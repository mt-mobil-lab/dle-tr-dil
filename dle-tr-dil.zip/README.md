# dle-tr-dil
datalife engine dil güncelleme eklendisi




## Çeviri Sahipleri

* **MaRZoCHi** DLE 9.7 ve sonrası
* **Supremacy** DLE 9.6 ve öncesi ( *Çevirileri için teşekkürler..* )
* ** Sonraki çeviriler çeşitli kaynaklardan derlenerek eklenecektir ** *






1) * Aşağıda yer alan dosyayı indirin
  
https://github.com/mt-mobil-lab/dle-tr-dil/blob/main/dle-tr-dil.zip

2) * Eklenti yükle kısmına gelin
  
![Ekran 1](/docs/screen1.png?raw=true)

3) * Eklentiyi yükleyin
  
![Ekran 2](/docs/screen2.png?raw=true)

4) * Eklenti güncellemelerini kontrol edin

![Ekran 3](/docs/screen3.png?raw=true)



* Kurulum sonrası `/templates/opensearch.tpl` dosyasını sitenize göre düzeltin
